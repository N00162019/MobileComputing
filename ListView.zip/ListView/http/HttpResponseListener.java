package com.bookstore.app.http;

import java.util.EventListener;

/**
 * Created by john on 09/02/2016.
 */
public interface HttpResponseListener extends EventListener {
    public void onHttpResponse(HttpResponseEvent event);
}
