package com.bookstore.app.http;

import java.util.EventObject;

/**
 * Created by john on 09/02/2016.
 */
public class HttpResponseEvent extends EventObject {

    private HttpResponse response;

    public HttpResponseEvent(Object source, HttpResponse response) {
        super(source);

        this.response = response;
    }

    public HttpResponse getResponse() {
        return this.response;
    }
}
