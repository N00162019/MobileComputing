package com.bookstore.listview;

// imported user-defined packages
import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.List;

// MainActivity class inherits from AppCompatActivity containing key java functions
// Implements the book list fragment that displays a list of books by binding to the item listener interface
public class MainActivity extends AppCompatActivity implements BookListFragment.ItemListener {

    // Declares pane variable
    private boolean mTwoPane;

    @Override
    // Saves the state of the application in a bundle
    // can be passed back to onCreate if the activity needs to be recreated
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Defines Twopane
        mTwoPane = (findViewById(R.id.book_details_two_pane) != null);
        if (mTwoPane) {
            // Retrieves books from model
            List<Book> books = Model.getInstance().getBooks();
            if (!books.isEmpty()) {
                // If there are books present, they are acquired by their id
                Book book = Model.getInstance().getBooks().get(0);
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.add(R.id.book_details_two_pane, BookDetailFragment.newInstance(book.getId()));
                ft.commit();
            }
        }
    }

    @Override
    // Defines the itemSelected function
    public void itemSelected(Book b) {
        if (mTwoPane) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();


            ft.replace(R.id.book_details_two_pane, BookDetailFragment.newInstance(b.getId()));
            ft.commit();
        }
        else {
            Intent intent = new Intent(this, BookDetailActivity.class);
            intent.putExtra(BookDetailFragment.EXTRA_BOOK_ID, b.getId());

            startActivity(intent);
        }
    }
}
