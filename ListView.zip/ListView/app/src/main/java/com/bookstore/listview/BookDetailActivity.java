package com.bookstore.listview;

// imported user-defined packages
import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

// BookDetailActivity class inherits from AppCompatActivity containing key java functions
public class BookDetailActivity extends AppCompatActivity {

    @Override
    // Saves the state of the application in a bundle
    // can be passed back to onCreate if the activity needs to be recreated
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        // Retrieves the book id from BookDetailFragment
        Intent intent = getIntent();
        int book_id = intent.getIntExtra(BookDetailFragment.EXTRA_BOOK_ID, -1);

        // Getting the supportLibrary fragmentManager
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();

        ft.add(R.id.book_details_one_pane, BookDetailFragment.newInstance(book_id));
        ft.commit();
    }
}
