package com.bookstore.listview;

// imported user-defined packages
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;

// Class inherits from Fragment parent class (and it's methods)
public class BookListFragment extends Fragment {

    // Listens for book click
    public interface ItemListener {
        public void itemSelected(Book b);
    }

    // Access variable for main activity
    private MainActivity mActivity = null;

    // Declaration of Shared Preferences
    private SharedPreferences.Editor editor = null;

    // Constructor of BookListFragment
    public BookListFragment() {}

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ItemListener){
            this.mActivity = (MainActivity) context;
        }
    }

    @Override
    // When this view is loaded, it gets a layout file from fragment_book_list
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_book_list, container, false);
    }

    @Override
    // Fuction used to put books in the list view layout
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Gets shared preferences
        SharedPreferences pref = getActivity().getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        editor = pref.edit();

        RecyclerView mRecyclerView = view.findViewById(R.id.book_list_view);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(mActivity);
        mRecyclerView.setLayoutManager(mLayoutManager);

        List<Book> books = Model.getInstance().getBooks();

        RecyclerView.Adapter adapter = new BookListAdapter(mActivity, books);
        mRecyclerView.setAdapter(adapter);
    }
}
