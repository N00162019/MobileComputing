package com.bookstore.listview;

// imported user-defined packages
import java.util.ArrayList;
import java.util.List;

// Define the model class
public class Model {

    // Declare static members (to be assigned values)
    private static Model instance = null;
    private final List<Book> mBooks;
    private ArrayList<Integer> selected = new ArrayList<Integer>();

    // Ensures there is only one instance of the Model class
    public static Model getInstance() {
        if (instance == null) {
            instance = new Model();
        }
        return instance;
    }

    private Model() {

        // Initialize the array list (hardcoding the values)
        mBooks = new ArrayList<>();
        getBooks().add(new Book(1, "Color: And it's Application to Printing", "E.C Andrews", "9781491933572", 2016,41.99, "https://ia802703.us.archive.org/BookReader/BookReaderPreview.php?id=coloritsapplicat00andriala&itemPath=%2F2%2Fitems%2Fcoloritsapplicat00andriala&server=ia802703.us.archive.org&page=cover_w200.jpg"));
        getBooks().add(new Book(2, "Harry Potter and the Prisoner of Azkaban", "J.K Rowling", "9780470413968", 2009, 36.40, "https://images-na.ssl-images-amazon.com/images/I/51NuYi4-XoL.jpg"));
        getBooks().add(new Book(3, "Magic T", "Paul McAvenue", "9781118903339", 2015, 40.90, "https://ia902604.us.archive.org/BookReader/BookReaderImages.php?id=panamapacificint00moor&itemPath=%2F7%2Fitems%2Fpanamapacificint00moor&server=ia902604.us.archive.org&page=page15_x280_y292_w668_h1080_s4.jpg"));
        getBooks().add(new Book(4, "The Tattooist of Auschwitz", "Heather Morris", "9781491914915", 2016, 39.99, "https://images-eu.ssl-images-amazon.com/images/I/51Zp2PkPeCL.jpg"));
        getBooks().add(new Book(5, "The Ice Monster", "David Walliams", "9780321767530", 2011, 26.31, "https://images-na.ssl-images-amazon.com/images/I/51sM8s%2B3DTL._SX328_BO1,204,203,200_.jpg"));
        getBooks().add(new Book(6, "Past Tense: (Jack Reacher 23)", "Lee Child", "9780470684160", 2010, 28.90, "https://images-eu.ssl-images-amazon.com/images/I/51NGSpye08L._SY346_.jpg"));
        getBooks().add(new Book(7, "Lose Weight For Good", "Tom Kerridge", "9781449363260", 2014, 34.99, "https://images-na.ssl-images-amazon.com/images/I/51AAJG9KZWL._SX385_BO1,204,203,200_.jpg"));
        getBooks().add(new Book(8, "12 Rules for Life: An Antidote to Chaos", "Jordan Peterson", "9780321858474", 2012, 25.76, "https://images-na.ssl-images-amazon.com/images/I/41Zd2%2BGNO9L._SX323_BO1,204,203,200_.jpg"));
        getBooks().add(new Book(9, "Brief Answers to the Big Questions: the final book from Stephen Hawking", "Stephen Hawking", "9780321784421", 2011, 17.95, "https://images-na.ssl-images-amazon.com/images/I/41JU-lDfebL._SX310_BO1,204,203,200_.jpg"));
        getBooks().add(new Book(10, "The Roasting Tin: Simple One Dish Dinners", "Rukmini Iyer", "9781491918050", 2015, 35.72, "https://images-na.ssl-images-amazon.com/images/I/516Mp3%2B3uWL._SX332_BO1,204,203,200_.jpg"));
        getBooks().add(new Book(11, "The official DVSA theory test for car drivers", "Driver and Vehicle Standards Agency", "9781118356555", 2012, 36.55, "https://images-na.ssl-images-amazon.com/images/I/517RzTIIkNL._SX350_BO1,204,203,200_.jpg"));
        getBooks().add(new Book(12, "The Rumour", "Lesley Kara", "9781754926555", 2004, 28.95, "https://images-eu.ssl-images-amazon.com/images/I/519ogkdLdHL.jpg"));
        getBooks().add(new Book(13, "Why We Sleep: The New Science of Sleep and Dreams", "Matthew Walker", "9781339956555", 2018, 45.00, "https://images-na.ssl-images-amazon.com/images/I/417dHCBAGEL._SX324_BO1,204,203,200_.jpg"));
        getBooks().add(new Book(14, "The Killer Collective", "Barry Eisler", "9781339999785", 1999, 22.00, "https://images-eu.ssl-images-amazon.com/images/I/414o2j%2BP8oL.jpg"));

    }

    // Returns the book list values from the books array.
    public List<Book> getBooks() {
        return mBooks;
    }

    // Function that returns each book using the book id
    public Book findBookById(int book_id) {
        Book book = null;
        for (Book b : mBooks) {
            if (b.getId() == book_id) {
                book = b;
                break;
            }
        }
        return book;
    }

    public void addToCart(int bookId) {

    }
}
